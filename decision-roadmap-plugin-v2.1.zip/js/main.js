// main.js — Entry point for Decision Roadmap V2.1
// Created by AmytheCh

(function () {
  "use strict";

  Sidebar.createSidebar();

  // Listen for toggle from background (icon click)
  try {
    chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
      if (message && message.action === "toggleSidebar") {
        Sidebar.toggle();
        sendResponse({ ok: true });
      }
      return true;
    });
  } catch (e) {}

  // Keyboard shortcut: Cmd+Shift+D (Mac) or Ctrl+Shift+D (Win/Linux)
  document.addEventListener("keydown", function(e) {
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === "D" || e.key === "d")) {
      e.preventDefault();
      Sidebar.toggle();
    }
  });

  // Floating toggle button — iPhone 4 home button style, Chrome color scheme
  var fab = document.createElement("div");
  fab.id = "dr-fab";
  fab.title = "Decision Roadmap";
  fab.style.cssText = [
    "position:fixed",
    "bottom:24px",
    "right:24px",
    "width:36px",
    "height:36px",
    "border-radius:10px",
    "background:linear-gradient(180deg, #f5f5f5 0%, #ddd 100%)",
    "border:1.5px solid #bbb",
    "box-shadow:0 1px 4px rgba(0,0,0,0.15), inset 0 1px 0 rgba(255,255,255,0.8)",
    "display:flex",
    "align-items:center",
    "justify-content:center",
    "cursor:pointer",
    "z-index:99998",
    "transition:transform 0.15s, box-shadow 0.15s",
    "user-select:none"
  ].join(";") + ";";

  // Inner circle like iPhone 4 home button
  var inner = document.createElement("div");
  inner.style.cssText = [
    "width:18px",
    "height:18px",
    "border-radius:5px",
    "border:1.5px solid #aaa",
    "background:transparent",
    "display:flex",
    "align-items:center",
    "justify-content:center"
  ].join(";") + ";";

  // Small rounded square icon inside
  var dot = document.createElement("div");
  dot.style.cssText = "width:8px;height:8px;border-radius:2px;border:1px solid #999;";
  inner.appendChild(dot);
  fab.appendChild(inner);

  fab.addEventListener("mouseenter", function() {
    fab.style.transform = "scale(1.08)";
    fab.style.boxShadow = "0 2px 8px rgba(0,0,0,0.2), inset 0 1px 0 rgba(255,255,255,0.8)";
  });
  fab.addEventListener("mouseleave", function() {
    fab.style.transform = "scale(1)";
    fab.style.boxShadow = "0 1px 4px rgba(0,0,0,0.15), inset 0 1px 0 rgba(255,255,255,0.8)";
  });
  fab.addEventListener("mousedown", function() {
    fab.style.background = "linear-gradient(180deg, #e8e8e8 0%, #ccc 100%)";
  });
  fab.addEventListener("mouseup", function() {
    fab.style.background = "linear-gradient(180deg, #f5f5f5 0%, #ddd 100%)";
  });
  fab.addEventListener("click", function() { Sidebar.toggle(); });
  document.body.appendChild(fab);

  console.log("[Decision Roadmap V2.1] Loaded. Cmd+Shift+D or click the button to open.");
})();
