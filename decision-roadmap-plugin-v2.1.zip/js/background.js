// background.js — Toggle sidebar when extension icon is clicked
// Created by AmytheCh

chrome.action.onClicked.addListener(function(tab) {
  if (!tab || !tab.id) return;
  chrome.tabs.sendMessage(tab.id, { action: "toggleSidebar" }, function(response) {
    // Suppress errors when content script isn't loaded yet
    if (chrome.runtime.lastError) {
      console.log("[Decision Roadmap] Content script not ready on this page.");
    }
  });
});
