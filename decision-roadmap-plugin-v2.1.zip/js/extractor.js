// extractor.js — Scrape conversation messages from AI platform DOMs
// Created by AmytheCh — V2.1

const Extractor = (() => {

  function detectPlatform() {
    var host = window.location.hostname;
    if (host.includes("claude.ai")) return "claude";
    if (host.includes("chatgpt.com") || host.includes("chat.openai.com")) return "chatgpt";
    if (host.includes("gemini.google.com")) return "gemini";
    return "unknown";
  }

  function anchorId(index) { return "dr-msg-" + index; }

  function scrollToMessage(index) {
    var el = document.getElementById(anchorId(index));
    if (!el) return;
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    el.style.transition = "outline 0.3s, outline-offset 0.3s";
    el.style.outline = "2px solid #639922";
    el.style.outlineOffset = "4px";
    setTimeout(function() {
      el.style.outline = "none";
      el.style.outlineOffset = "0";
    }, 2000);
  }

  // ===== Claude — 2026 DOM structure =====
  // User messages: [class*="font-user-message"] (has ! prefix in Tailwind)
  // Assistant messages: [class*="font-claude-response"] (split into many blocks per turn)
  // Strategy: collect all user elements in DOM order, then for each user element
  // gather all assistant blocks that appear AFTER it and BEFORE the next user element
  function extractClaude() {
    var userEls = Array.from(document.querySelectorAll('[class*="font-user-message"]'));
    var assistantEls = Array.from(document.querySelectorAll('[class*="font-claude-response"]'));

    if (userEls.length === 0 && assistantEls.length === 0) return [];

    // Build a combined list sorted by DOM position
    var all = [];
    userEls.forEach(function(el) { all.push({ el: el, type: "user" }); });
    assistantEls.forEach(function(el) { all.push({ el: el, type: "assistant" }); });

    // Sort by document order
    all.sort(function(a, b) {
      var pos = a.el.compareDocumentPosition(b.el);
      if (pos & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
      if (pos & Node.DOCUMENT_POSITION_PRECEDING) return 1;
      return 0;
    });

    // Group into turns: each user message starts a new turn,
    // consecutive assistant blocks merge into one assistant message
    var turns = [];
    var currentTurn = null;

    all.forEach(function(item) {
      if (item.type === "user") {
        if (currentTurn) turns.push(currentTurn);
        currentTurn = {
          userEl: item.el,
          userText: item.el.innerText.trim(),
          assistantTexts: [],
          assistantEl: null
        };
      } else {
        // assistant block
        if (!currentTurn) {
          // assistant before any user message
          currentTurn = { userEl: null, userText: "", assistantTexts: [], assistantEl: null };
        }
        var text = item.el.innerText.trim();
        if (text.length > 0) {
          currentTurn.assistantTexts.push(text);
          if (!currentTurn.assistantEl) currentTurn.assistantEl = item.el;
        }
      }
    });
    if (currentTurn) turns.push(currentTurn);

    // Convert turns to messages array
    var messages = [];
    var msgIndex = 0;

    turns.forEach(function(turn) {
      if (turn.userText.length > 0 && turn.userEl) {
        turn.userEl.id = anchorId(msgIndex);
        turn.userEl.dataset.drAnchor = anchorId(msgIndex);
        messages.push({
          index: msgIndex,
          anchorId: anchorId(msgIndex),
          role: "user",
          content: turn.userText,
          charCount: turn.userText.length
        });
        msgIndex++;
      }

      // Merge all assistant blocks for this turn into one message
      // But deduplicate — sometimes nested elements repeat text
      var assistantText = deduplicateAssistantText(turn.assistantTexts);
      if (assistantText.length > 0) {
        var anchorEl = turn.assistantEl;
        if (anchorEl) {
          anchorEl.id = anchorId(msgIndex);
          anchorEl.dataset.drAnchor = anchorId(msgIndex);
        }
        messages.push({
          index: msgIndex,
          anchorId: anchorId(msgIndex),
          role: "assistant",
          content: assistantText,
          charCount: assistantText.length
        });
        msgIndex++;
      }
    });

    return messages;
  }

  // Deduplicate assistant text blocks — longer blocks often contain shorter ones
  function deduplicateAssistantText(texts) {
    if (texts.length <= 1) return texts.join("");

    // Sort by length descending — longer texts likely contain shorter ones
    var sorted = texts.slice().sort(function(a, b) { return b.length - a.length; });
    var unique = [];

    sorted.forEach(function(text) {
      // Check if this text is already contained in any accepted text
      var isDuplicate = unique.some(function(u) { return u.includes(text); });
      if (!isDuplicate) unique.push(text);
    });

    return unique.join("\n\n");
  }

  // ===== ChatGPT =====
  function extractChatGPT() {
    var articles = document.querySelectorAll('article[data-testid^="conversation-turn"]');
    if (articles.length === 0) articles = document.querySelectorAll('[data-message-id]');
    return Array.from(articles).map(function(el, i) {
      el.id = anchorId(i);
      el.dataset.drAnchor = anchorId(i);
      var isUser = !!(el.querySelector('[data-message-author-role="user"]') || el.className.includes("user"));
      var contentEl = el.querySelector(".markdown, .whitespace-pre-wrap") || el;
      var content = contentEl.innerText.trim();
      return { index: i, anchorId: anchorId(i), role: isUser ? "user" : "assistant", content: content, charCount: content.length };
    }).filter(function(m) { return m.content.length > 0; });
  }

  // ===== Gemini =====
  function extractGemini() {
    var turns = document.querySelectorAll("message-content, .conversation-turn");
    return Array.from(turns).map(function(el, i) {
      el.id = anchorId(i);
      el.dataset.drAnchor = anchorId(i);
      var isUser = !!(el.closest('[data-author-type="user"]') || el.className.includes("user"));
      var content = el.innerText.trim();
      return { index: i, anchorId: anchorId(i), role: isUser ? "user" : "assistant", content: content, charCount: content.length };
    }).filter(function(m) { return m.content.length > 0; });
  }

  function extract() {
    var platform = detectPlatform();
    var messages = [];
    switch (platform) {
      case "claude": messages = extractClaude(); break;
      case "chatgpt": messages = extractChatGPT(); break;
      case "gemini": messages = extractGemini(); break;
    }
    return { platform: platform, extractedAt: new Date().toISOString(), messageCount: messages.length, messages: messages };
  }

  return { extract: extract, scrollToMessage: scrollToMessage, detectPlatform: detectPlatform };
})();
