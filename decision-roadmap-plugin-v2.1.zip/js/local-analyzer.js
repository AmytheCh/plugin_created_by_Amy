// local-analyzer.js — Local conversation analysis, zero token cost
// Created by AmytheCh — V2.1

const LocalAnalyzer = (() => {

  // Keywords for status detection
  var kw_decided = ["decided","agreed","confirmed","chosen","settled","finalized","conclusion","will use","going with","the plan is","we'll do","let's do","决定","确定","选择","敲定","拍板","结论","方案是","就这样","同意","采用","确认","就用","做法是"];
  var kw_discussing = ["considering","debating","comparing","thinking about","what if","option","alternative","pros and cons","trade-off","should we","could we","maybe","perhaps","versus","vs","or we could","考虑","讨论","对比","权衡","要不要","选项","利弊","取舍","或者","也许","是否","比较","还是","怎么看"];
  var kw_blocked = ["blocked","waiting on","depends on","can't proceed","stuck","prerequisite","before we can","阻塞","等待","依赖","卡住","前提","先要","才能","无法继续"];
  var kw_risk = ["risk","concern","worry","downside","danger","careful","caveat","warning","problem is","风险","担心","问题是","隐患","注意","小心","代价","缺点","弊端","麻烦"];
  var kw_action = ["next step","todo","to do","action item","need to","will do","implement","build","create","write","design","start with","下一步","待办","要做","需要做","实现","搭建","编写","设计","开始做","先做"];

  function countMatches(text, kwList) {
    var lower = text.toLowerCase();
    var count = 0;
    kwList.forEach(function(k) { if (lower.includes(k.toLowerCase())) count++; });
    return count;
  }

  function inferStatus(text) {
    var d = countMatches(text, kw_decided);
    var disc = countMatches(text, kw_discussing);
    var b = countMatches(text, kw_blocked);
    if (b > 0 && b >= d) return "blocked";
    if (d > 0 && d >= disc) return "decided";
    if (disc > 0) return "discussing";
    return "pending";
  }

  // Get first meaningful sentence
  function firstSentence(text, maxLen) {
    maxLen = maxLen || 80;
    if (!text) return "";
    // Remove "Searched the web" and similar tool artifacts
    text = text.replace(/^Searched the web[.\s]*/i, "").trim();
    var parts = text.split(/[。！？\.\!\?\n]+/).filter(function(s) { return s.trim().length > 3; });
    if (parts.length === 0) return text.substring(0, maxLen);
    var s = parts[0].trim();
    return s.length > maxLen ? s.substring(0, maxLen) + "..." : s;
  }

  // Extract risks from text
  function extractRisks(text) {
    if (countMatches(text, kw_risk) === 0) return null;
    var items = [];
    text.split(/[。！？\.\!\?\n]+/).forEach(function(s) {
      s = s.trim();
      if (s.length > 10 && countMatches(s, kw_risk) > 0) {
        items.push(s.length > 120 ? s.substring(0, 120) + "..." : s);
      }
    });
    return items.length > 0 ? items.slice(0, 3) : null;
  }

  // Extract action items from text
  function extractActions(text) {
    if (countMatches(text, kw_action) === 0) return null;
    var items = [];
    text.split(/[。！？\.\!\?\n]+/).forEach(function(s) {
      s = s.trim();
      if (s.length > 10 && countMatches(s, kw_action) > 0) {
        items.push({ done: false, text: s.length > 120 ? s.substring(0, 120) + "..." : s });
      }
    });
    return items.length > 0 ? items.slice(0, 5) : null;
  }

  // Extract a decision sentence
  function extractDecision(text) {
    if (countMatches(text, kw_decided) === 0) return null;
    var sentences = text.split(/[。！？\.\!\?\n]+/);
    for (var i = 0; i < sentences.length; i++) {
      var s = sentences[i].trim();
      if (s.length > 10 && countMatches(s, kw_decided) > 0) {
        return s.length > 150 ? s.substring(0, 150) + "..." : s;
      }
    }
    return null;
  }

  // Main analysis
  function analyze(messages) {
    if (!messages || messages.length === 0) return [];

    // Group into conversation turns (user + following assistant messages)
    var turns = [];
    var current = null;

    messages.forEach(function(msg) {
      if (msg.role === "user") {
        if (current) turns.push(current);
        current = { userText: msg.content, assistantText: "", startIndex: msg.index };
      } else if (msg.role === "assistant") {
        if (!current) {
          current = { userText: "", assistantText: msg.content, startIndex: msg.index };
        } else {
          current.assistantText += "\n" + msg.content;
        }
      }
    });
    if (current) turns.push(current);

    // Build nodes from turns
    var nodes = [];
    var id = 0;

    turns.forEach(function(turn) {
      var fullText = (turn.userText + "\n" + turn.assistantText).trim();

      // Skip very short or trivial turns
      if (fullText.length < 40) return;

      // Skip tool artifacts
      if (fullText.match(/^(Searched the web|Loading|undefined)/i) && fullText.length < 100) return;

      id++;
      var userSummary = firstSentence(turn.userText, 70);
      var assistantSummary = firstSentence(turn.assistantText, 150);
      var status = inferStatus(fullText);
      var decision = extractDecision(turn.assistantText);
      var risks = extractRisks(fullText);
      var actions = extractActions(fullText);

      // Title: use user question, fallback to assistant opening
      var title = userSummary || assistantSummary || "Topic " + id;

      nodes.push({
        id: String(id),
        title: { en: title, zh: title },
        status: status,
        problem: userSummary ? { en: userSummary, zh: userSummary } : null,
        discussion: assistantSummary ? { en: assistantSummary, zh: assistantSummary } : null,
        decision: decision ? { en: decision, zh: decision } : null,
        basis: null,
        risks: risks ? { en: risks, zh: risks } : null,
        actions: actions ? { en: actions, zh: actions } : null,
        sourceIndex: turn.startIndex,
        children: null
      });
    });

    return nodes;
  }

  return { analyze: analyze };
})();
