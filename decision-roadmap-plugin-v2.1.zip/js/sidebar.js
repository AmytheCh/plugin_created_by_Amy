// sidebar.js — Decision Roadmap sidebar panel (V2.1, Local Analysis)
// Created by AmytheCh

const Sidebar = (() => {
  var lang = "en";
  var filter = "all";
  var roadmapData = [];
  var isVisible = false;

  var i18n = {
    en: {
      title: "Decision Roadmap",
      analyze: "Analyze Conversation",
      total: "Total", decided: "Decided", discussing: "Discussing", open: "Open",
      all: "All", pending: "Pending", blocked: "Blocked",
      problem: "Problem", discussion: "Discussion", decision: "Decision",
      basis: "Basis", risks: "Risks / Trade-offs", actions: "Action Items",
      expand: "+", collapse: "\u2212",
      emptyTitle: "No decisions yet",
      emptyText: "Have a conversation, then click Analyze.",
      jumpTo: "Jump to source",
      noMessages: "No messages found on this page.",
      done: "Done!",
      msgCount: "messages analyzed",
    },
    zh: {
      title: "\u51b3\u7b56\u8def\u7ebf\u56fe",
      analyze: "\u5206\u6790\u5bf9\u8bdd",
      total: "\u603b\u8ba1", decided: "\u5df2\u51b3\u7b56", discussing: "\u8ba8\u8bba\u4e2d", open: "\u5f85\u5904\u7406",
      all: "\u5168\u90e8", pending: "\u5f85\u542f\u52a8", blocked: "\u963b\u585e",
      problem: "\u95ee\u9898\u5b9a\u4e49", discussion: "\u8ba8\u8bba\u8fc7\u7a0b", decision: "\u51b3\u7b56\u7ed3\u8bba",
      basis: "\u51b3\u7b56\u4f9d\u636e", risks: "\u98ce\u9669\u4e0e\u53d6\u820d", actions: "\u5f85\u529e\u4e8b\u9879",
      expand: "+", collapse: "\u2212",
      emptyTitle: "\u6682\u65e0\u51b3\u7b56\u8bb0\u5f55",
      emptyText: "\u5f00\u59cb\u5bf9\u8bdd\u540e\uff0c\u70b9\u51fb\u300c\u5206\u6790\u5bf9\u8bdd\u300d\u3002",
      jumpTo: "\u8df3\u8f6c\u5230\u539f\u6587",
      noMessages: "\u5f53\u524d\u9875\u9762\u672a\u627e\u5230\u5bf9\u8bdd\u6d88\u606f\u3002",
      done: "\u5b8c\u6210\uff01",
      msgCount: "\u6761\u6d88\u606f\u5df2\u5206\u6790",
    },
  };

  var statusColors = { decided: "#639922", discussing: "#EF9F27", pending: "#888780", blocked: "#E24B4A" };

  function T(k) { return i18n[lang][k] || k; }
  function L(v) { if (!v) return null; if (typeof v === "string") return v; return v[lang] || v.en || ""; }

  function createSidebar() {
    if (document.getElementById("dr-sidebar")) return;
    var el = document.createElement("div");
    el.id = "dr-sidebar";
    el.classList.add("hidden");
    el.innerHTML =
      '<div class="dr-header">' +
        '<span class="dr-header-title">' + T("title") + '</span>' +
        '<div class="dr-header-actions">' +
          '<button class="dr-btn" id="dr-lang-toggle">\u4e2d\u6587</button>' +
          '<button class="dr-btn-close" id="dr-close-btn">&times;</button>' +
        '</div>' +
      '</div>' +
      '<div class="dr-action-bar">' +
        '<button class="dr-btn dr-btn-primary" id="dr-analyze-btn" style="flex:1">' +
          '\u25b6 ' + T("analyze") +
        '</button>' +
      '</div>' +
      '<div class="dr-status-msg hidden" id="dr-status-msg"></div>' +
      '<div class="dr-toolbar" id="dr-filter-bar"></div>' +
      '<div class="dr-stats" id="dr-stats"></div>' +
      '<div class="dr-tree-wrap"><div class="dr-tree" id="dr-tree"></div></div>' +
      '<div class="dr-footer">Created by AmytheCh</div>';
    document.body.appendChild(el);

    document.getElementById("dr-close-btn").addEventListener("click", toggle);
    document.getElementById("dr-lang-toggle").addEventListener("click", toggleLang);
    document.getElementById("dr-analyze-btn").addEventListener("click", runAnalysis);
    document.getElementById("dr-filter-bar").addEventListener("click", handleFilter);
  }

  function toggle() {
    var el = document.getElementById("dr-sidebar");
    if (!el) { createSidebar(); return toggle(); }
    isVisible = !isVisible;
    el.classList.toggle("hidden", !isVisible);
    if (isVisible) { loadFromStorage(); render(); }
  }

  function toggleLang() {
    lang = lang === "en" ? "zh" : "en";
    document.getElementById("dr-lang-toggle").textContent = lang === "en" ? "\u4e2d\u6587" : "EN";
    render();
  }

  function handleFilter(e) {
    var chip = e.target.closest(".dr-chip");
    if (!chip) return;
    filter = chip.dataset.filter;
    render();
  }

  function showStatus(msg, type) {
    var el = document.getElementById("dr-status-msg");
    el.textContent = msg;
    el.className = "dr-status-msg dr-status-" + type;
    if (type !== "loading") setTimeout(function() { el.classList.add("hidden"); }, 5000);
  }

  // ===== LOCAL ANALYSIS =====
  function runAnalysis() {
    var data = Extractor.extract();
    if (data.messages.length === 0) {
      showStatus(T("noMessages"), "error");
      return;
    }

    // Run local analysis — instant, no tokens
    var nodes = LocalAnalyzer.analyze(data.messages);
    roadmapData = nodes;
    saveToStorage();
    render();
    showStatus(data.messages.length + " " + T("msgCount") + " \u2014 " + T("done"), "success");
  }

  // ===== STORAGE =====
  function saveToStorage() {
    try { chrome.storage.local.set({ drRoadmap: roadmapData, drLang: lang }); } catch (e) {}
  }
  function loadFromStorage() {
    try {
      chrome.storage.local.get(["drRoadmap", "drLang"], function(r) {
        if (r.drRoadmap && Array.isArray(r.drRoadmap)) roadmapData = r.drRoadmap;
        if (r.drLang) lang = r.drLang;
        document.getElementById("dr-lang-toggle").textContent = lang === "en" ? "\u4e2d\u6587" : "EN";
        render();
      });
    } catch (e) {}
  }

  // ===== RENDER =====
  function flatNodes(nodes) {
    var r = [];
    nodes.forEach(function(n) { r.push(n); if (n.children) r.push.apply(r, n.children); });
    return r;
  }
  function counts() {
    var c = { decided: 0, discussing: 0, pending: 0, blocked: 0 };
    flatNodes(roadmapData).forEach(function(n) { if (c.hasOwnProperty(n.status)) c[n.status]++; });
    return c;
  }

  function renderStats() {
    var c = counts(), total = c.decided + c.discussing + c.pending + c.blocked;
    document.getElementById("dr-stats").innerHTML =
      '<div class="dr-stat"><div class="dr-stat-num">' + total + '</div><div class="dr-stat-label">' + T("total") + '</div></div>' +
      '<div class="dr-stat"><div class="dr-stat-num" style="color:#639922">' + c.decided + '</div><div class="dr-stat-label">' + T("decided") + '</div></div>' +
      '<div class="dr-stat"><div class="dr-stat-num" style="color:#EF9F27">' + c.discussing + '</div><div class="dr-stat-label">' + T("discussing") + '</div></div>' +
      '<div class="dr-stat"><div class="dr-stat-num" style="color:#888780">' + (c.pending + c.blocked) + '</div><div class="dr-stat-label">' + T("open") + '</div></div>';
  }

  function renderFilters() {
    var keys = ["all", "decided", "discussing", "pending", "blocked"];
    document.getElementById("dr-filter-bar").innerHTML = keys.map(function(k) {
      return '<button class="dr-chip' + (filter === k ? " active" : "") + '" data-filter="' + k + '">' + T(k) + '</button>';
    }).join("");
  }

  function renderNode(n) {
    var title = L(n.title) || "(untitled)";
    var dims = "";

    ["problem", "discussion", "decision", "basis"].forEach(function(f) {
      var val = L(n[f]);
      if (val) dims += '<div class="dr-dim"><div class="dr-dim-label">' + T(f) + '</div><div class="dr-dim-text">' + val + '</div></div>';
    });

    var risks = n.risks ? (n.risks[lang] || n.risks.en || n.risks) : null;
    if (Array.isArray(risks) && risks.length) {
      dims += '<div class="dr-dim"><div class="dr-dim-label">' + T("risks") + '</div>';
      risks.forEach(function(r) { dims += '<div class="dr-dim-text"><span class="dr-risk-tag">!</span> ' + r + '</div>'; });
      dims += '</div>';
    }

    var actions = n.actions ? (n.actions[lang] || n.actions.en || n.actions) : null;
    if (Array.isArray(actions) && actions.length) {
      dims += '<div class="dr-dim"><div class="dr-dim-label">' + T("actions") + '</div>';
      actions.forEach(function(a) {
        dims += '<div class="dr-action"><span class="dr-action-check">' + (a.done ? "[x]" : "[ ]") + '</span><span>' + a.text + '</span></div>';
      });
      dims += '</div>';
    }

    var srcIdx = (n.sourceIndex !== undefined && n.sourceIndex !== null) ? n.sourceIndex : null;
    if (srcIdx !== null) {
      dims += '<div class="dr-dim"><span class="dr-source" data-source-index="' + srcIdx + '">' + T("jumpTo") + ' \u2192 #' + srcIdx + '</span></div>';
    }

    var childrenHtml = "";
    if (n.children && n.children.length) {
      var fc = n.children.filter(function(ch) { return filter === "all" || ch.status === filter; });
      if (fc.length) childrenHtml = '<div class="dr-children">' + fc.map(function(ch) { return renderNode(ch); }).join("") + '</div>';
    }

    var status = n.status || "pending";
    return '<div class="dr-node" data-id="' + n.id + '">' +
      '<div class="dr-node-hdr" data-toggle="' + n.id + '">' +
        '<div class="dr-dot" style="background:' + (statusColors[status] || "#888") + '"></div>' +
        '<div><span class="dr-node-title">' + n.id + ' ' + title +
          ' <span class="dr-badge dr-badge-' + status + '">' + T(status) + '</span>' +
          '<span class="dr-hint" id="dr-hint-' + n.id + '">' + T("expand") + '</span></span></div>' +
      '</div>' +
      '<div class="dr-node-body" id="dr-body-' + n.id + '">' + dims + childrenHtml + '</div>' +
    '</div>';
  }

  function renderTree() {
    var tree = document.getElementById("dr-tree");
    if (!roadmapData || roadmapData.length === 0) {
      tree.innerHTML = '<div class="dr-empty"><div class="dr-empty-icon">\ud83d\uddfa</div><div class="dr-empty-text"><strong>' + T("emptyTitle") + '</strong><br>' + T("emptyText") + '</div></div>';
      return;
    }
    var filtered = roadmapData.filter(function(n) {
      if (filter === "all") return true;
      if (n.status === filter) return true;
      return n.children && n.children.some(function(c) { return c.status === filter; });
    });
    tree.innerHTML = filtered.map(function(n) { return renderNode(n); }).join("");

    tree.querySelectorAll("[data-toggle]").forEach(function(el) {
      el.addEventListener("click", function() {
        var id = el.dataset.toggle;
        var body = document.getElementById("dr-body-" + id);
        var hint = document.getElementById("dr-hint-" + id);
        if (body) {
          var open = body.classList.toggle("open");
          if (hint) hint.textContent = open ? T("collapse") : T("expand");
        }
      });
    });

    tree.querySelectorAll("[data-source-index]").forEach(function(el) {
      el.addEventListener("click", function(e) {
        e.stopPropagation();
        Extractor.scrollToMessage(parseInt(el.dataset.sourceIndex));
      });
    });
  }

  function render() {
    var ht = document.querySelector(".dr-header-title");
    if (ht) ht.textContent = T("title");
    var ab = document.getElementById("dr-analyze-btn");
    if (ab) ab.innerHTML = "\u25b6 " + T("analyze");
    renderStats();
    renderFilters();
    renderTree();
  }

  return { createSidebar: createSidebar, toggle: toggle, render: render };
})();
